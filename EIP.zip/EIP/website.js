document.addEventListener("DOMContentLoaded", () => {
    const wrapper = document.querySelector(".carousel-wrapper");
    const slides = document.querySelectorAll(".slide");

    // Clone slides for seamless looping
    slides.forEach(slide => {
        const clone = slide.cloneNode(true);
        wrapper.appendChild(clone);
    });
});






